﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public class_test obj = new class_test();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] strings = { "4999", "longestString", "23", "notLongest" };
            
            MessageBox.Show( obj.getLongestString(strings));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string showMsg = "";
            int a = 0;
            if(textBox1.Text.Trim() == "")
            {
                showMsg = "Please key in a number !";

            }
            else if (!int.TryParse(textBox1.Text.Trim(), out  a))
            {
                showMsg = "Input must be numeric !";
            }
            else
            {
                showMsg = "Output : " + obj.recursiveSumAll(Convert.ToInt32(textBox1.Text.Trim())).ToString();
            }
            MessageBox.Show(showMsg);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int[] foo = { 2, 5, 9, 13, 16, 19, 20, 21 };
            int[] bar = { 1, 5, 7, 8, 12, 22, 29 };
            int a = 0;
            string showMsg = "";
            if (textBox1.Text.Trim() == "")
            {
                showMsg = "Please key in a number !";

            }
            else if (!int.TryParse(textBox1.Text.Trim(), out a))
            {
                showMsg = "Input must be numeric !";
            }
            else
            {
                int[] res = obj.getLeastKNumber(foo, bar, Convert.ToInt32(textBox2.Text.Trim()));
                foreach(int b in res)
                {
                    showMsg = showMsg + b.ToString() + " ";
                }
                showMsg = "Output : " + showMsg;
            }
            MessageBox.Show(showMsg);

           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            List<class_employee> cls_emp = new List<class_employee>();
           
            string reportees = "";
            cls_emp.Add(new class_employee { name = "CEO", id = "1", manager = null });
            cls_emp.Add(new class_employee { name = "e1", id = "2", manager = "1" });
            cls_emp.Add(new class_employee { name = "e5", id = "6", manager = "3" });
            cls_emp.Add(new class_employee { name = "e2", id = "3", manager = "2" });
            cls_emp.Add(new class_employee { name = "e3", id = "4", manager = "2" });
            cls_emp.Add(new class_employee { name = "e4", id = "5", manager = "3" });

            cls_emp.Add(new class_employee { name = "e6", id = "7", manager = "4" });

          

            reportees = obj.getReportees(cls_emp, textBox3.Text.Trim());
            MessageBox.Show(reportees);
        }
    }
}
