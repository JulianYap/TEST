﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class class_employee
    {
        public string name { set; get; }
        public string id { set; get; }
        public string manager { set; get; }
    }
}
