﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WindowsFormsApplication1
{
    
    public class class_test
    {
        
        public string getLongestString(string[] my_array)
        {
            string longestString = "";
            int[] count = new int[my_array.Length];
            int i = 0;
            foreach(string str in my_array)
            {
                count[i] = str.Length;
                i++;
            }
            // Find maximum number.
            int selectMax = count.Max();
            longestString = Convert.ToString(my_array[count.ToList().IndexOf(selectMax)]);
            return longestString;
        }

        public int recursiveSumAll(int num)
        {
            int intResult = 0;

            for(int i = 0 ; i < num; i++)
            {
                intResult = intResult + i + 1;
            }

            return intResult;
        }

        public int[] getLeastKNumber(int[] foo, int[] bar, int k)
        {
            
            int[] result = new int[k];
            int[] tmp = foo.Concat(bar).ToArray();
            tmp = (from i in tmp orderby i ascending select i).ToArray();

            for (int i = 0; i < k; i ++ )
            {
                result[i] = tmp[i];
            }

            return result;
        }

        public string getReportees(List<class_employee> class_emp, string manager)
        {
            string result = "";
            List<string> ManagerList = new List<string>();
            List<class_employee> SortedList = class_emp.OrderBy(o => o.manager).ToList();
            List<class_employee> managerID = new List<class_employee>(class_emp.FindAll(x => x.name == manager));
            ManagerList.Add(managerID[0].id);

            foreach (class_employee emp in SortedList)
            {
                for (int i = 0; i < ManagerList.Count; i++)
                {
                    if (ManagerList[i] == emp.manager)
                    {
                        ManagerList.Add(emp.id);
                    }
                }

            }

            List<class_employee> Result = new List<class_employee>(class_emp.FindAll(x => ManagerList.Contains(x.manager)));

            foreach (class_employee staff in Result)
            {
                result = result + staff.name + " ";
            }
            return result;
        }
    }
}
